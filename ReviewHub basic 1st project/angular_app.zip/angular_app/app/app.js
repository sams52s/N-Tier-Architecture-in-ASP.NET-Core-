var app = angular.module("myApp", ["ngRoute"]);
var API_ROOT = "https://localhost:44317/";
app.config(["$routeProvider","$locationProvider",function($routeProvider,$locationProvider) {

    $routeProvider
    .when("/", {
        templateUrl : "views/pages/demopage.html"
    })
    .when("/SinUp", {
        templateUrl : "views/pages/SinUp.html",
        controller: 'SinUp'
    })
    .when("/UserTypes", {
        templateUrl : "views/pages/UserTypes.html",
        controller: 'UserTypes'
    })
    .otherwise({
        redirectTo:"/"
    });
      //$locationProvider.html5Mode(true);
      //$locationProvider.hashPrefix('');
      //if(window.history && window.history.pushState){
      //$locationProvider.html5Mode(true);
  //}

}]);
