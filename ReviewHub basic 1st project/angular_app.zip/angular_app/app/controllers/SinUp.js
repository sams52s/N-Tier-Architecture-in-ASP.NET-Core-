app.controller("SinUp",function($scope,ajax,$location){

  ajax.get("https://localhost:44317/api/UserType/GetAll",
  function(resp){
    $scope.UserTypes = resp.data;
  },
  function(err){

  });

  $scope.SinUp = function(s){
     ajax.post(API_ROOT+"api/User/Add",s,
     function(resp){
          $location.path("/UserTypes");
     },function(err){});

  };
});
