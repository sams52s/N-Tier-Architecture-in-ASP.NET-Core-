app.controller("UserTypes",function($scope,ajax){
    ajax.get("https://localhost:44317/api/UserType/GetAll",function(response){
      $scope.UserTypes = response.data;
    },
    function(error){

    });
});
